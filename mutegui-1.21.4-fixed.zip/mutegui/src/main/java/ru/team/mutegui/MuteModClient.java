package ru.team.mutegui;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.*;
import net.minecraft.util.Formatting;

public class MuteModClient implements ClientModInitializer {
    public static MuteConfig CONFIG;

    @Override
    public void onInitializeClient() {
        CONFIG = MuteConfig.load();

        // Внутренняя клиентская команда, которую вызывает красная кнопка
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("mutegui_open")
                        .then(ClientCommandManager.argument("player", StringArgumentType.word())
                                .executes(ctx -> {
                                    String player = StringArgumentType.getString(ctx, "player");
                                    MinecraftClient mc = MinecraftClient.getInstance();
                                    mc.execute(() -> {
                                        if (mc.player == null) return;
                                        mc.player.networkHandler.sendChatCommand(CONFIG.openCommand);
                                        mc.setScreen(new MuteScreen(player));
                                    });
                                    return 1;
                                }))));

        // Обычные сообщения игроков (подписанные сообщения чата) идут через MODIFY_CHAT,
        // а не MODIFY_GAME — поэтому раньше кнопка не появлялась вообще.
        // Ник берём напрямую из профиля отправителя, без регулярок — работает на любом сервере.
        ClientReceiveMessageEvents.MODIFY_CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> {
            if (sender == null) return message;
            String player = sender.getName();
            if (player == null || player.isEmpty()) return message;

            MutableText button = Text.literal("[✖] ").setStyle(Style.EMPTY
                    .withColor(Formatting.RED)
                    .withBold(true)
                    .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/mutegui_open " + player))
                    .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                            Text.literal("Замутить " + player).formatted(Formatting.RED))));

            return Text.empty().append(button).append(message);
        });
    }
}
